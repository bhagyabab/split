package com.update.splitwse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

import com.update.splitwse.entity.Group;

public interface GroupRepository extends JpaRepository<Group, Long> {

    @Query(value = "SELECT g1_0.user_id, g1_1.group_id, g1_1.group_name " +
                   "FROM group_members g1_0 " +
                   "JOIN `groups` g1_1 ON g1_1.group_id = g1_0.group_id " +
                   "WHERE g1_0.user_id = :userId", nativeQuery = true)
    List<Object[]> findGroupsByUserId(@Param("userId") Long userId);
}
