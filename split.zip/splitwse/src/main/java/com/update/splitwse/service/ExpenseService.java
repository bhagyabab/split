package com.update.splitwse.service;

import com.update.splitwse.dto.ExpenseRequest;
import com.update.splitwse.entity.Expense;
import com.update.splitwse.entity.User;
import com.update.splitwse.repository.ExpenseRepository;
import com.update.splitwse.repository.UserRepository;
import com.update.splitwse.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private UserRepository userRepository;

    // Add expense to the group
    public void addExpense(ExpenseRequest expenseRequest) {
        Double amount = expenseRequest.getAmount();
        Long groupId = expenseRequest.getGroupId();
        List<Long> splitAmong = expenseRequest.getSplitAmong();
        String description = expenseRequest.getDescription();
        String dateString = expenseRequest.getDate();

        // Convert string to LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(dateString, formatter);

        List<User> users = userRepository.findAllById(splitAmong);

        Expense expense = new Expense();
        expense.setAmount(amount);
        expense.setGroupId(groupId);
        expense.setDescription(description);
        expense.setDate(date); // Set as LocalDate
        expense.setUsers(users);

        expenseRepository.save(expense);
    }

    // Get expense by ID and groupId
    public Expense getExpenseById(Long groupId, Long expenseId) {
        return expenseRepository.findByGroupIdAndExpenseId(groupId, expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found for the given group and expenseId"));
    }

    // List all expenses for a group
    public List<Expense> listAllExpenses(Long groupId) {
        return expenseRepository.findByGroupId(groupId);
    }
}
