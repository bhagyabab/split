package com.update.splitwse.repository;

import com.update.splitwse.entity.Expense;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {

    // Find an expense by groupId and expenseId
    Optional<Expense> findByGroupIdAndExpenseId(Long groupId, Long expenseId);

    // Find all expenses for a group
    List<Expense> findByGroupId(Long groupId);
}
