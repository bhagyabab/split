package com.update.splitwse.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.update.splitwse.dto.UserRequest;
import com.update.splitwse.entity.User;
import com.update.splitwse.service.UserService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Show Thymeleaf registration form
    @GetMapping("/register")
    public String showRegistrationForm(org.springframework.ui.Model model) {
        model.addAttribute("user", new UserRequest());
        return "register"; // Return Thymeleaf form view
    }

    // Register via HTML form but return JSON response
    @PostMapping("/register") // Adjusted endpoint to match requirement
    @ResponseBody
    public ResponseEntity<Map<String, Object>> registerUserFromForm(
            @Valid @RequestBody UserRequest userRequest, // Use @RequestBody for REST API
            BindingResult result) {

        if (result.hasErrors()) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("status", "Validation failed");
            errorResponse.put("errors", result.getFieldErrors());
            return ResponseEntity.badRequest().body(errorResponse);
        }

        User savedUser = userService.registerUser(userRequest);

        Map<String, Object> response = new HashMap<>();
        response.put("userId", savedUser.getUserId());
        response.put("status", "User registered successfully!");

        return ResponseEntity.ok(response); // Return 200 OK response
    }

    // Get user details by userId
    @GetMapping("/{userId}")
    @ResponseBody
    public ResponseEntity<User> getUserDetails(@PathVariable Long userId) {
        return userService.getUserById(userId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Update user details
    @PutMapping("/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable Long userId, @RequestBody User updatedUser) {
        // Ensure the user exists, then update and return the updated user.
        User user = userService.updateUser(userId, updatedUser);
        
        if (user == null) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(user);  // Return updated user details
    }
}
