package com.update.splitwse.controller;

import com.update.splitwse.dto.BalanceRequest;
import com.update.splitwse.entity.Balance;
import com.update.splitwse.service.BalanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/balance")
public class BalanceController {

    @Autowired
    private BalanceService balanceService;

    //  Get user's balances in a group
    @GetMapping("/user/{userId}/group/{groupId}")
    public ResponseEntity<List<Balance>> getUserBalances(@PathVariable Long userId,
                                                         @PathVariable Long groupId) {
        List<Balance> balances = balanceService.getUserBalances(userId, groupId);
        return ResponseEntity.ok(balances);
    }

    //  Settle a balance
    @PostMapping("/settle/{userId}")
    public ResponseEntity<String> settleBalance(@PathVariable Long userId,
                                                @RequestBody BalanceRequest balanceRequest) {
        balanceService.settleBalance(userId, balanceRequest);
        return ResponseEntity.ok("Balance settled successfully");
    }
}
