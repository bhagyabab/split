package com.update.splitwse.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public class ExpenseRequest {

    @NotNull
    private Long groupId; 

    @NotNull
    private Double amount; 

    @NotNull
    private Long paidById; 

    @NotNull
    private List<Long> splitAmongUserIds; 

    private String description; // Optional description of the expense

    // Getters and setters

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Long getPaidById() {
        return paidById;
    }

    public void setPaidById(Long paidById) {
        this.paidById = paidById;
    }

    public List<Long> getSplitAmongUserIds() {
        return splitAmongUserIds;
    }

    public void setSplitAmongUserIds(List<Long> splitAmongUserIds) {
        this.splitAmongUserIds = splitAmongUserIds;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
 // In ExpenseRequest.java
    public List<Long> getSplitAmong() {
        return splitAmongUserIds;  
    }

}
