package com.update.splitwse.service;

import com.update.splitwse.dto.BalanceRequest;
import com.update.splitwse.entity.Balance;
import com.update.splitwse.entity.Group;
import com.update.splitwse.entity.User;
import com.update.splitwse.repository.BalanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BalanceService {

    @Autowired
    private BalanceRepository balanceRepository;

    public List<Balance> getUserBalances(Long userId, Long groupId) {
        // Fetch balances for user in the specific group
        return balanceRepository.findByGroupAndOwedTo(new Group(groupId), new User(userId));
    }

    public void settleBalance(Long userId, BalanceRequest balanceRequest) {
        // Your logic to settle the balance, update the Balance entity
    }
}
