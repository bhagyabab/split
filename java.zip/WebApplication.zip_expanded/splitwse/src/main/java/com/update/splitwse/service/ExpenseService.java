package com.update.splitwse.service;

import com.update.splitwse.dto.ExpenseRequest;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ExpenseService {

    // Adjust the method to accept ExpenseRequest
    public void addExpense(ExpenseRequest expenseRequest) {
        // Extract parameters from the expenseRequest object
        Double amount = expenseRequest.getAmount();
        Long groupId = expenseRequest.getGroupId();
        List<Long> splitAmong = expenseRequest.getSplitAmong();
        String description = expenseRequest.getDescription();
        
        // Logic to add expense, e.g., save to DB
        // Example:
        // Expense expense = new Expense(amount, groupId, splitAmong, description);
        // expenseRepository.save(expense);
    }
}
