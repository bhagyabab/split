package com.update.splitwse.controller;

import com.update.splitwse.dto.GroupRequest;
import com.update.splitwse.dto.AddRemoveUsers;
import com.update.splitwse.entity.Group;
import com.update.splitwse.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/groups")
public class GroupController {

    @Autowired
    private GroupService groupService;

    //  Create Group
    @PostMapping
    public ResponseEntity<?> createGroup(@RequestBody GroupRequest request) {
        Group createdGroup = groupService.createGroup(request.getGroupName(), request.getUsersId());

        Map<String, Object> response = new HashMap<>();
        response.put("groupId", createdGroup.getGroupId());
        response.put("status", "Group created successfully!");
        return ResponseEntity.ok(response);
    }

    //  Add / Remove users
    @PutMapping("/{groupId}/members")
    public ResponseEntity<?> updateMembers(@PathVariable Long groupId,
                                           @RequestBody AddRemoveUsers request) {
        List<Long> updatedMembers = groupService.updateGroupMembers(groupId, request);

        Map<String, Object> response = new HashMap<>();
        response.put("groupId", groupId);
        response.put("members", updatedMembers);
        return ResponseEntity.ok(response);
    }

    //  Get Group Details
    @GetMapping("/{groupId}")
    public ResponseEntity<GroupRequest> getGroupById(@PathVariable Long groupId) {
        GroupRequest group = groupService.getGroupById(groupId);
        return ResponseEntity.ok(group);
    }

    // 4️⃣ List All Groups
    @GetMapping
    public ResponseEntity<List<GroupRequest>> getAllGroups() {
        List<GroupRequest> groups = groupService.getAllGroups();
        return ResponseEntity.ok(groups);
    }
}
