package com.update.splitwse.service;

import com.update.splitwse.dto.UserRequest;
import com.update.splitwse.entity.User;
import com.update.splitwse.exception.UserNotFoundException;
import com.update.splitwse.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Register a new user using DTO
    public User registerUser(UserRequest userRequest) {
        User user = new User();
        user.setName(userRequest.getName());
        user.setEmail(userRequest.getEmail());
        user.setPassword(userRequest.getPassword());
        user.setPhone(userRequest.getPhone());
        return userRepository.save(user);
    }

    //  Get user details by ID
    public Optional<User> getUserById(Long userId) {
        return userRepository.findById(userId);
    }

    //  Get user by email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
    }

    //  Update user details
    public User updateUser(Long userId, UserRequest userRequest) {
        User updateUser = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        updateUser.setName(userRequest.getName());
        updateUser.setEmail(userRequest.getEmail());
        updateUser.setPassword(userRequest.getPassword());
        updateUser.setPhone(userRequest.getPhone());

        return userRepository.save(updateUser);
    }

    //  List all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    //  Get multiple users by IDs
    public List<User> getAllUsersByIds(List<Long> userIds) {
        return userRepository.findAllById(userIds);
    }
}
