package com.update.splitwse.service;

import com.update.splitwse.dto.GroupRequest;
import com.update.splitwse.dto.AddRemoveUsers;
import com.update.splitwse.entity.Group;
import com.update.splitwse.entity.User;
import com.update.splitwse.exception.ResourceNotFoundException;
import com.update.splitwse.repository.GroupRepository;
import com.update.splitwse.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GroupService {

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private UserRepository userRepository;

    // Create group
    public Group createGroup(String groupName, List<Long> usersId) {
        List<User> members = userRepository.findAllById(usersId);

        if (members.size() != usersId.size()) {
            throw new ResourceNotFoundException("Some user IDs do not exist.");
        }

        Group group = new Group();
        group.setGroupName(groupName);
        group.setMembers(members);

        return groupRepository.save(group);
    }

    // Add / Remove Members
    public List<Long> updateGroupMembers(Long groupId, AddRemoveUsers request) {
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found"));

        // Add members
        if (request.getUserIdsToAdd() != null) {
            List<User> usersToAdd = userRepository.findAllById(request.getUserIdsToAdd());
            group.getMembers().addAll(usersToAdd);
        }

        // Remove members
        if (request.getUserIdsToRemove() != null) {
            group.getMembers().removeIf(u -> request.getUserIdsToRemove().contains(u.getUserId()));
        }

        groupRepository.save(group);

        // Return updated member IDs
        return group.getMembers().stream().map(User::getUserId).collect(Collectors.toList());
    }

    // Get group details
    public GroupRequest getGroupById(Long groupId) {
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found"));

        List<Long> usersId = group.getMembers() != null
                ? group.getMembers().stream().map(User::getUserId).toList()
                : List.of();

        return new GroupRequest(group.getGroupName(), usersId);
    }

    // List all groups
    public List<GroupRequest> getAllGroups() {
        return groupRepository.findAll()
                .stream()
                .map(group -> new GroupRequest(
                        group.getGroupName(),
                        group.getMembers() != null
                                ? group.getMembers().stream().map(User::getUserId).toList()
                                : List.of()
                ))
                .collect(Collectors.toList());
    }
}
