package com.update.splitwse.entity;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Balance implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long balanceId;

    @ManyToOne
    private User owedTo;

    @ManyToOne
    private User owedFrom;

    @ManyToOne
    private Group group;

    private Double amountOwed;

    // --- Constructors ---

    public Balance() {
        // default constructor
    }

    public Balance(Long balanceId, User owedTo, User owedFrom, Group group, Double amountOwed) {
        this.balanceId = balanceId;
        this.owedTo = owedTo;
        this.owedFrom = owedFrom;
        this.group = group;
        this.amountOwed = amountOwed;
    }

    // --- Getters and Setters ---

    public Long getBalanceId() {
        return balanceId;
    }

    public void setBalanceId(Long balanceId) {
        this.balanceId = balanceId;
    }

    public User getOwedTo() {
        return owedTo;
    }

    public void setOwedTo(User owedTo) {
        this.owedTo = owedTo;
    }

    public User getOwedFrom() {
        return owedFrom;
    }

    public void setOwedFrom(User owedFrom) {
        this.owedFrom = owedFrom;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public Double getAmountOwed() {
        return amountOwed;
    }

    public void setAmountOwed(Double amountOwed) {
        this.amountOwed = amountOwed;
    }
}
