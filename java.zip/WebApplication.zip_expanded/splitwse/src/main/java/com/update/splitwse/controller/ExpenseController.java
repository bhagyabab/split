package com.update.splitwse.controller;

import com.update.splitwse.dto.ExpenseRequest;
import com.update.splitwse.service.ExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    //  Add expense
    @PostMapping("/add")
    public ResponseEntity<String> addExpense(@RequestBody ExpenseRequest expenseRequest) {
        try {
            expenseService.addExpense(expenseRequest);
            return new ResponseEntity<>("Expense added successfully", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error adding expense", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
