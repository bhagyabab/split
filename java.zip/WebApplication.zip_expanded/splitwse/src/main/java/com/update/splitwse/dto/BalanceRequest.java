package com.update.splitwse.dto;

import jakarta.validation.constraints.NotNull;

public class BalanceRequest {
    @NotNull
    private Long owedToUserId;

    @NotNull
    private Long owedFromUserId;

    @NotNull
    private Double amountOwed;

    // Getters and setters
    public Long getOwedToUserId() {
        return owedToUserId;
    }

    public void setOwedToUserId(Long owedToUserId) {
        this.owedToUserId = owedToUserId;
    }

    public Long getOwedFromUserId() {
        return owedFromUserId;
    }

    public void setOwedFromUserId(Long owedFromUserId) {
        this.owedFromUserId = owedFromUserId;
    }

    public Double getAmountOwed() {
        return amountOwed;
    }

    public void setAmountOwed(Double amountOwed) {
        this.amountOwed = amountOwed;
    }
}
