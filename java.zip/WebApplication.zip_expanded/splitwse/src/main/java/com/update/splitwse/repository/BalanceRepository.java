package com.update.splitwse.repository;

import com.update.splitwse.entity.Balance;
import com.update.splitwse.entity.User;
import com.update.splitwse.entity.Group;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BalanceRepository extends JpaRepository<Balance, Long> {

    // Find balance by owedTo and owedFrom for a specific group
    Optional<Balance> findByOwedToAndOwedFromAndGroup(User owedTo, User owedFrom, Group group);

    // Find all balances for a specific user in a group
    List<Balance> findByGroupAndOwedTo(Group group, User owedTo);

    // Find all balances in a group
    List<Balance> findByGroup(Group group);
}
