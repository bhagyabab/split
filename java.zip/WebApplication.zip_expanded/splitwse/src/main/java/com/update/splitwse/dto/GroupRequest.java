package com.update.splitwse.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GroupRequest {
    private String groupName;

    @JsonProperty("usersId")
    private List<Long> usersId;  

    public GroupRequest() {}

    public GroupRequest(String groupName, List<Long> usersId) {
        this.groupName = groupName;
        this.usersId = usersId;
    }

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<Long> getUsersId() {
		return usersId;
	}

	public void setUsersId(List<Long> usersId) {
		this.usersId = usersId;
	}

    
}
